Usage
=====

* Clone the repository:
    git clone git@github.com:gre/chess-game.git

* Init submodules dependencies (WebAppBuilder)
    git submodule init; git submodule update

WebAppBuilder dependencies
====
* nodejs for WebAppBuilder
